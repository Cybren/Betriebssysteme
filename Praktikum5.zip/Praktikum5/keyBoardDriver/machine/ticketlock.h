
#pragma once

class Ticketlock {
private:
    Ticketlock(const Ticketlock &copy);
public:
    Ticketlock() {}

    void lock() {
    }

    void unlock() {
    }
};

