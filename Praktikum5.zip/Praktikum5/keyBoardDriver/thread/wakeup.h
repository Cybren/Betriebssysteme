
#pragma once
#include "guard/gate.h"
#include "machine/plugbox.h"

extern Plugbox plugbox;

class WakeUp
        : public Gate {
public:

};

