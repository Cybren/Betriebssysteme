#include "null_stream.h"

Null_Stream nullstream;

