#include "user/app1/appl.h"
#include "types.h"
#include "device/cga_stream.h"
extern CGA_Stream kout;
#include "syscall/guarded_bell.h"
#include "syscall/guarded_semaphore.h"
extern Guarded_Semaphore koutsem;

void Application::action ()
{

}
