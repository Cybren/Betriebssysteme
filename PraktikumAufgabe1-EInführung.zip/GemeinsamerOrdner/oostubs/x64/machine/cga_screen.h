/*! \file
 *  \brief Enthält die Klasse zum Zugriff auf den CGA_Screen
 */

#pragma once

#include "types.h"

/*! \brief Abstraktion des CGA-Textmodus.
 *  \ingroup io
 *
 *
 *  Mit Hilfe dieser Klasse kann man auf den Bildschirm des PCs zugreifen.
 *  Der Zugriff erfolgt direkt auf der Hardwareebene, d.h. über den
 *  Bildschirmspeicher bzw. die I/O-Ports der Grafikkarte.
 *
 *  Die Implementierung soll es dabei ermöglichen die Ausgaben des CGA_Screens
 *  nur auf einem Teil des kompletten CGA-Bildschirms darzustellen, einem
 *  in seiner Position und Größe festgelegtem Fenster (mit eigenem Cursor).
 *  Dadurch ist es möglich die Ausgaben des Programms und etwaige Debugausgaben
 *  auf dem Bildschirm zu trennen, ohne synchronisieren zu müssen.
 */
class CGA_Screen
{
private:
	// Verhindere Kopien und Zuweisungen
	CGA_Screen(const CGA_Screen&)            = delete;
	CGA_Screen& operator=(const CGA_Screen&) = delete;
	int x_pos;
	int y_pos;
	int from_col;
	int to_col;
	int from_row;
	int to_row;
	int col_span;
	int row_span;

	bool use_cursor;

public:
	/*! \brief Konstruktor
	 *
	 *  Der CGA_Screen spannt ein Fenster auf der CGA-Bildschirmfläche auf, dass
	 *  durch das Rechteck colums*rows beschrieben wird.
	 *  \param from_col Fensterrechteck beginnt in Spalte from_col
	 *  \param to_col Fensterrechteck erstreckt sich bis Spalte to_col (inklusive)
	 *  \param from_row Fensterrechteck beginn in Zeile from_row
	 *  \param to_row Fensterrechteck erstreckt sich bis Zeile to_row (inklusive)
	 *  \param use_cursor Gibt an, ob der CGA Hardwarecursor verwendet werden
	 *  soll. Defaultmässig ist dies nicht der Fall.
	 *
	 */
	CGA_Screen(int from_col, int to_col, int from_row, int to_row, bool use_cursor=false);

	/// Groesse des kompletten CGA-Bildschirms
	static const int ROWS = 25;
	static const int COLUMNS = 80;

	/*! \brief CGA-Farben
	 *
	 *  Konstanten fuer die moeglichen Farben im Attribut-Byte. Für die
	 *  Hintergrundfarbe ist nur \c BLACK bis \c LIGHT_GREY moeglich.
	 */
	enum Color {
		BLACK, BLUE, GREEN, CYAN, RED, MAGENTA, BROWN, LIGHT_GREY,
		DARK_GREY, LIGHT_BLUE, LIGHT_GREEN, LIGHT_CYAN, LIGHT_RED,
		LIGHT_MAGENTA, YELLOW, WHITE
	};

	/*! \brief Struktur für [Farb]Attribute eines Zeichens
	 *
	 * Die Verwendung einer <a href="https://en.cppreference.com/w/cpp/language/bit_field">Bitfeldstruktur</a>
	 * erleichtert den Zugriff deutlich
	 */
	struct Attribute {
		uint8_t foreground : 4; // .... XXXX Vordergrundfarbe
		uint8_t background : 3; // .XXX .... Hintergrundfarbe
		uint8_t blink      : 1; // X... .... Blinken

		/*! \brief Attributkonstruktor
		 *
		 *  \param foreground Vordergrundfarbe (Standard LIGHT_GREY)
		 *  \param background Hintergrundfarbe (Standard BLACK)
		 *  \param blink blinkend oder nicht (Standard kein blinken)
		 */
		Attribute(Color foreground = LIGHT_GREY, Color background = BLACK, bool blink = false)
			:	foreground(foreground),
				background(background <= DARK_GREY ? background : BLACK),
				blink(blink)
			{
			};
	} __attribute__((packed)); // sorgt dafür, dass der Übersetzter keinen Speicher auffüllt

	/*! \brief Setzen des Cursors im Fenster auf Spalte \p x und Zeile \p y.
	 *
	 *  Abhängig vom Konstruktorparameter \c use_cursor wird hier entweder der
	 *  CGA Hardwarecursor verwendet, oder die Position intern im Objekt
	 *  gespeichert.
	 *
	 *  \param x Spalte im Fenster
	 *  \param y Zeile im Fenster
	 */
	void setpos (int x, int y);

	/*! \brief Abfragen der Cursorpostion
	 *
	 * Abhängig vom Konstruktorparameter \c use_cursor wird hier der
	 * CGA Hardwarecursor oder die intern gespeicherte Position verwendet.
	 *
	 *  \param x Spalte im Fenster
	 *  \param y Zeile im Fenster
	 */
	void getpos (int& x, int& y);

	/*! \brief Anzeige mehrerer Zeichen im Fenster ab der aktuellen Cursorposition
	 *
	 *  Mit dieser Methode kann eine Zeichenkette \p string ausgegeben werden, wobei
	 *  an der aktuellen Position des Cursors begonnen wird. Da die Zeichenkette
	 *  anders als sonst bei C üblich keine Nullterminierung zu enthalten braucht,
	 *  wird der Parameter \p length benötigt, der angeben muss, aus wievielen Zeichen
	 *  string besteht. Nach Abschluss der Ausgabe soll der Cursor hinter dem zuletzt
	 *  ausgegebenen Zeichen stehen. Der gesamte Text soll einheitlich mit den durch
	 *  \p attrib gewählten Farben dargestellt werden.
	 *
	 *  Wenn bis zum Ende der Zeile nicht mehr genügend Platz ist, soll die Ausgabe
	 *  auf der folgenden Zeile fortgesetzt werden. Sobald die letzte Fensterzeile
	 *  gefüllt ist, soll der gesamte Fensterbereich um eine Zeile nach oben
	 *  geschoben werden. Dadurch verschwindet die erste Zeile. Dafür kann nun die
	 *  letzte Zeile erst gelöscht und dann die Ausgabe dort fortgesetzt werden.
	 *
	 *  Ein Zeilenumbruch muss auch erfolgen, wann immer das Zeichen \c \\n im
	 *  auszugebenden Text enthalten ist.
	 *
	 *  \param string Auszugebende Zeichenkette
	 *  \param length Länge der Zeichenkette
	 *  \param attrib Farbattribut zur Darstellung
	 */
	void print (char* string, int length, Attribute attrib = Attribute());

	/*! \brief Löschen des Inhalts und Zurücksetzen des Cursors
	 *
	 *  \param character Füllzeichen
	 *  \param attrib Zeichenattribut
	 */
	void reset(char character=' ', Attribute attrib = Attribute());

	/*! \brief Grundlegende Anzeige eines Zeichens mit Attribut an einer bestimmten
	 * Stelle auf dem kompletten CGA-Bildschirm.
	 *
	 *  Diese Methode gibt das Zeichen \p character an der absoluten Position
	 *  (\p x, \p y) mit dem angegebenen Farbattribut attrib aus. Dabei gibt \p x die
	 *  Spalte und \p y die Zeile der gewünschten Position an, wobei gilt:
	 *  0 <= \p x <= 79 und 0 <= \p y <= 24. Die Position (0,0) bezeichnet die linke
	 *  obere Ecke des Bildschirms. Mit \p attrib lassen sich Merkmale wie
	 *  Hintergrundfarbe, Vordergrundfarbe und Blinken festlegen.
	 *
	 *  \param x Bildschirmspalte, in der das Zeichen dargestellt werden soll
	 *  \param y Bildschirmzeile, in der das Zeichen dargestellt werden soll
	 *  \param character Zeichen, welches dargestellt werden soll
	 *  \param attrib Farbattribut zur Darstellung
	 */
	static void show (int x, int y, char character, Attribute attrib = Attribute());

private:
	/*! \brief Struktur für ein Zeichen im CGA Textmodus
	 *
	 * Bestehend aus zwei Byte, dem Inhalt und den [Farb]Attribut
	 */
	struct Cell {
		char character;
		Attribute attribute;
	} __attribute__((packed));

	/// \brief Startadresse des CGA-Bildschirmspeichers
	static Cell * const CGA_START;

	// SCROLLUP: Verschiebt den Bildschirminhalt um eine Zeile nach oben.
	//           Die neue Zeile am unteren Bildrand wird mit Leerzeichen
	//           gefuellt.
	void scrollup ();
};
